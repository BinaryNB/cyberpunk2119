AddCSLuaFile()

if (CLIENT) then
	SWEP.PrintName = "Taser"
	SWEP.Slot = 1
	SWEP.SlotPos = 2
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
end

function SWEP:Initialize()
	self:SetDeploySpeed(1)
	self:SetWeaponHoldType(self.HoldType)
	self:SetMaterial("models/weapons/w_models/w_eq_taser/taser")
end

SWEP.FallbackMat = "models/weapons/csgo/taser"
SWEP.Author = "Tazmily"
SWEP.Category = "Nutscript"
SWEP.Instructions = "Aim and shoot at the desired target to knock them unconcious. A second strike will inflict pain."
SWEP.Purpose = "Crowd control."
SWEP.Drop = false

SWEP.HoldType = "pistol"

SWEP.Spawnable = true
SWEP.AdminOnly = true

SWEP.ViewModelFOV = 47
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "pistol"

SWEP.ViewTranslation = 4

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""
SWEP.Primary.Damage = 7.5
SWEP.Primary.Delay = 0.7

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

SWEP.ViewModel = "models/weapons/c_csgo_taser.mdl"
SWEP.WorldModel = "models/weapons/w_eq_taser.mdl"
SWEP.ViewModelFlip			= false

SWEP.UseHands = true
SWEP.LowerAngles = Angle(15, -10, -20)

SWEP.FireWhenLowered = true

function SWEP:SetupDataTables()
	self:NetworkVar("Bool", 1, "Activated")
end

function SWEP:Precache()
	util.PrecacheSound("weapons/stunstick/stunstick_swing1.wav")
	util.PrecacheSound("weapons/stunstick/stunstick_swing2.wav")
	util.PrecacheSound("weapons/stunstick/stunstick_impact1.wav")	
	util.PrecacheSound("weapons/stunstick/stunstick_impact2.wav")
	util.PrecacheSound("weapons/stunstick/spark1.wav")
	util.PrecacheSound("weapons/stunstick/spark2.wav")
	util.PrecacheSound("weapons/stunstick/spark3.wav")
end

function SWEP:Initialize()
	self:SetHoldType(self.HoldType)
end

function SWEP:PrimaryAttack()
    self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)

	if (!self.Owner:isWepRaised()) then
		return
	end

	if (CLIENT) then
		if (SERVER) then
			self:SetActivated(self:GetActivated())

			local sequence = "activatebaton"

			if (self:GetActivated()) then
				self.Owner:EmitSound("weapons/stunstick/spark3.wav", 100, math.random(90, 110))
				sequence = "activatebaton"
			else
				self.Owner:EmitSound("weapons/stunstick/spark"..math.random(1, 2)..".wav", 100, math.random(90, 110))
			end

			local model = string.lower(self.Owner:GetModel())
			
			if (nut.anim.getModelClass(model) == "metrocop") then
				self.Owner:forceSequence(sequence, nil, nil, true)
			end
		end

		return
	end

	self:EmitSound("weapons/psp/spin.wav", 70)
    self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	
	local damage = self.Primary.Damage

	if (self:GetActivated()) then
		damage = 5
	end

	self.Owner:SetAnimation(PLAYER_ATTACK1)
	self.Owner:ViewPunch(Angle(1, 0, 0.125))

	self.Owner:LagCompensation(true)
		local data = {}
			data.start = self.Owner:GetShootPos()
			data.endpos = data.start + self.Owner:GetAimVector()*100000
			data.filter = self.Owner
		local trace = util.TraceLine(data)
	self.Owner:LagCompensation(false)

	if (SERVER and trace.Hit) then
		if (self:GetActivated()) then
			local effect = EffectData()
				effect:SetStart(trace.HitPos)
				effect:SetNormal(trace.HitNormal)
				effect:SetOrigin(trace.HitPos)
			util.Effect("StunstickImpact", effect, true, true)
			
			else
			
			local effect = EffectData()
				effect:SetStart(trace.HitPos)
				effect:SetNormal(trace.HitNormal)
				effect:SetOrigin(trace.HitPos)
			util.Effect("StunstickImpact", effect, true, true)
		end

		self.Owner:EmitSound("weapons/psp/spin.wav")

		local entity = trace.Entity

		if (IsValid(entity)) then
			if (entity:IsPlayer()) then
				if (self:GetActivated()) then
					entity.nutStuns = (entity.nutStuns or 0) + 1

					timer.Simple(10, function()
						entity.nutStuns = math.max(entity.nutStuns - 1, 0)
					end)
				end

				entity:ViewPunch(Angle(-20, math.random(-15, 15), math.random(-10, 10)))

				if (self:GetActivated() and entity.nutStuns > (0)) then
					entity:setRagdolled(true, 60)
					entity.nutStuns = 0
					
				else
				
				entity:setRagdolled(true, 60)
					entity.nutStuns = 0
					return
				end
			elseif (entity:IsRagdoll()) then
				if (self:GetActivated()) then
					damage = 2
				else
					damage = 10
				end
			end

			local damageInfo = DamageInfo()
				damageInfo:SetAttacker(self.Owner)
				damageInfo:SetInflictor(self)
				damageInfo:SetDamage(damage)
				damageInfo:SetDamageType(DMG_SHOCK)
				damageInfo:SetDamagePosition( Vector (10000, 1000, 1000))
				damageInfo:SetDamageForce(self.Owner:GetAimVector()*10000)
			entity:DispatchTraceAttack(damageInfo, data.start, data.endpos)
		end
	end
end


function SWEP:OnLowered()
	self:SetActivated(true)
end

function SWEP:Holster(nextWep)
	self:OnLowered()

	return true
end

/*---------------
WORLDMODEL-FIXING UTILITY CODE
ORIGINALLY BY ROBOTBOY
----------------*/
    //SWEP.FixWorldModel = false
	SWEP.FixWorldModel = true
     
    SWEP.FixWorldModelPos = Vector( -3, 0, 0 )
     
    SWEP.FixWorldModelAng = Angle( 0, 0, 0 )
     
    SWEP.FixWorldModelScale = 1
     
function SWEP:DoFixWorldModel()
            if ( IsValid( self.Owner ) ) then
                    local att = self.Owner:GetAttachment( self.Owner:LookupAttachment( "anim_attachment_RH" ) )
                    if ( !att ) then return end
                    local pos, ang = att.Pos, att.Ang
                    ang:RotateAroundAxis( ang:Forward(), self.FixWorldModelAng.p )
                    ang:RotateAroundAxis( ang:Right(), self.FixWorldModelAng.y )
                    ang:RotateAroundAxis( ang:Up(), self.FixWorldModelAng.r )
                    pos = pos + ang:Forward() * self.FixWorldModelPos.x + ang:Right() * self.FixWorldModelPos.y + ang:Up() * self.FixWorldModelPos.z
                    self:SetModelScale( self.FixWorldModelScale, 0 )
                    self:SetRenderOrigin( pos )
                    self:SetRenderAngles( ang )
            else
                    self:SetRenderOrigin( self:GetNetworkOrigin() )
                    self:SetRenderAngles( self:GetNetworkAngles() )
            end 
end 

function SWEP:DrawWorldModel()
            if ( self.FixWorldModel ) then self:DoFixWorldModel() end
            self:DrawModel()
end