ITEM.name = "Plated Sushi"
ITEM.uniqueID = "food_sushi"
ITEM.model = "models/nt/props_street/sushiplate.mdl"
ITEM.hungerAmount = 10
ITEM.desc = "A fancy styled plate with local fashioned sushi."
ITEM.quantity = 2
ITEM.price = 5
ITEM.width = 1
ITEM.height = 1
--4 perception
ITEM.flag = "f"

ITEM.attribBoosts = { ["perception"] = 4 }