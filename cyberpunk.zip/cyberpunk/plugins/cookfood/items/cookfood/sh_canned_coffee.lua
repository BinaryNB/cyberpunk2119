ITEM.name = "Canned Coffee"
ITEM.uniqueID = "food_soda_coffee"
ITEM.model = "models/nt/props_debris/can02.mdl"
ITEM.hungerAmount = 3
ITEM.desc = "An aluminium can filled with coffee."
ITEM.quantity = 2
ITEM.price = 1
ITEM.width = 1
ITEM.height = 1
ITEM.cookable = false
ITEM.skin = 1
ITEM.container = "j_empty_soda_can"
ITEM.dropscontainer = true
ITEM.sound = "npc/barnacle/barnacle_gulp1.wav"
ITEM.flag = "f"


ITEM.attribBoosts = { ["accuracy"] = 4, ["agility"] = 4, ["luck"] = 3  }