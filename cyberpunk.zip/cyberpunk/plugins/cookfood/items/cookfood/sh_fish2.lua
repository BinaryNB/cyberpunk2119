ITEM.name = "Fish"
ITEM.uniqueID = "food_fish2"
ITEM.model = "models/props/de_inferno/goldfish.mdl"
ITEM.hungerAmount = 15
ITEM.desc = "A common fish."
ITEM.quantity = 2
ITEM.price = 6
ITEM.width = 2
ITEM.height = 1
--4 agi
ITEM.flag = "f"

ITEM.attribBoosts = { ["stm"] = 4 }