local PLUGIN = PLUGIN

local DISEASE = {}

DISEASE.uid = "dis_cyberpsych"
DISEASE.name = "Cyberpsychosis"
DISEASE.desc = "You've lost your sanity to all the augments."
DISEASE.category = "Mental"
DISEASE.phase = {
	"Something is wrong with you, your feel unstable, and uncertain.",
	"You hear dozens of voices screaming in your head, and they just won't stop.",
	"You have a terrible urge to do something damaging to yourself.",
	"You don't feel like you're controlling yourself, like you're some kind of puppet.",
	"You just want to go home. You just want to be safe.",
	"You see strange objects in the corner of your vision.",
	"You hear someone call your name.",
	"Someone is watching you from far away.",
	"The ground is unsteady, and moving by itself.",
	"The sky is blood red, but when you blink it returns to normal.",
	"The walls begin to bleed, this goes on for several minutes before returning to normal.",
	"Your hands are covered in blood, but when you blink they return to normal.",
	"Out of the corner of your vision you see a someone approaching, but when you turn there is no one there.",
	"You are suddenly falling from a great height, but a moment later find yourself back on your feet.",
	"For a moment, everyone around you is a terrifying monster, they seemingly return to normal a minute later.",
	"You can see moving shapes in the shadows around you.",
	"You feel your skin crawling away from you, your bones screaming, and your head expanding. You feel normal a moment or so later.",
	"You feel like someone is watching you.",
	"Someone is following you.",
	"You feel like something is watching you from the ceiling.",
	"Out of the corner of your eye you spot something watching you.",
	"You feel someone breathing down your neck.",
	"Someone touches your left shoulder.",
	"You hear footsteps behind you.",
	"You see something in the distance looking at you, but when you look again you see nothing.",
	"Something is coming for you.",
	"You swear you hear someone whisper your name.",
	"You feel as though if you talk too loudly, 'they' will hear you. You don't want that.",
	"You feel like something is coming after you.",
	"Something is right behind you.",
}
DISEASE.cure = {
	"You feel whole again.",
}

DISEASES:Register( DISEASE )
//