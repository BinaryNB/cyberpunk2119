ATTRIBUTE.name = "Accuracy"
ATTRIBUTE.desc = "Your character's accuracy with ranged attacks."