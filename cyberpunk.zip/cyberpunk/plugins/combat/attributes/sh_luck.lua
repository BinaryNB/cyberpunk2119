ATTRIBUTE.name = "Luck"
ATTRIBUTE.desc = "Your character's mysterious power over random chance."