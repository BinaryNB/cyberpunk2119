ITEM.name = "Adhesive"
ITEM.uniqueID = "j_scrap_adhesive"
ITEM.model = "models/props_lab/jar01a.mdl"
ITEM.desc = "Some adhesive."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1
ITEM.maxstack = 25

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(-200, 0, 0),
	ang = Angle(0, -0, 0),
	fov = 5,
}

