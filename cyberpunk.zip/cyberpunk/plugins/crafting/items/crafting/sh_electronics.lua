ITEM.name = "Scrap Electronics"
ITEM.uniqueID = "j_scrap_elecs"
ITEM.model = "models/gibs/scanner_gib04.mdl"
ITEM.desc = "Some scrap electronic parts."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(122.72621917725, 102.70703887939, 74.21459197998),
	ang = Angle(25, 220, 0),
	fov = 4.4700027532942,
}