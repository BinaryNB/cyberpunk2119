ITEM.name = "Glass"
ITEM.uniqueID = "j_scrap_glass"
ITEM.model = "models/props_junk/garbage_glassbottle001a_chunk04.mdl"
ITEM.material = "models/props/cs_assault/moneywrap"
ITEM.desc = "Some glass."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1
ITEM.maxstack = 40

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(82.60001373291, 70.64037322998, 52.150852203369),
	ang = Angle(25, 220, 0),
	fov = 4.3222649865396
}