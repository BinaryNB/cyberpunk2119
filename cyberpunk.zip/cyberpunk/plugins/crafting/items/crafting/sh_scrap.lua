ITEM.name = "Scrap"
ITEM.uniqueID = "c_scrap"
ITEM.model = "models/gibs/scanner_gib02.mdl"
ITEM.desc = "Scrap materials scavenged from some object."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(174.22866821289, 146.35655212402, 106.09148406982),
	ang = Angle(25, 220, 0),
	fov = 3.5,
}