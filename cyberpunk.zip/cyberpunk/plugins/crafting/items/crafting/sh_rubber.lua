ITEM.name = "Some Rubber"
ITEM.uniqueID = "j_scrap_rubber"
ITEM.model = "models/gibs/antlion_gib_small_3.mdl"
ITEM.desc = "A small container of some rubber."
ITEM.flag = "j"
ITEM.width = 1
ITEM.height = 1

ITEM.data = {
	Amount = 1
}

ITEM.iconCam = {
	pos = Vector(-0.5, 0, 200),
	ang = Angle(90, 0, 0),
	fov = 5.25,
}