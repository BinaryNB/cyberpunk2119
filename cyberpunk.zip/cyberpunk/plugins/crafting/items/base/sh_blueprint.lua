ITEM.name = "Base Blueprint"
ITEM.category = "Blueprints"
ITEM.model = "models/props_lab/clipboard.mdl"