ITEM.name = "RATNIK-5"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=255,0,0>[Vissei Concern]</color> Vissei’s newest exo-skeleton gives the operator the power they need while making making sure not to compromise the users well being inside the exo-skeleton. However the downside of using this beast is the painful realization that running is impossible and jogging is near impossible. Materials used: Industrial steel alloys, aluminum, strong servos & aftermarket electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 9500
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = -30,
["str"] = 25,
["end"] = 10,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}