ITEM.name = "[MOD] Reverse Interface"
ITEM.desc = "<color=100,250,180>[TriTek]</color> A neural implant that allows the machines to interface with the user and receive information from them, so long as they're plugged in."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "neuralware"
ITEM.flag = "x"
ITEM.price = 500
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}