ITEM.name = "[R LEG] Pallas-60H"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=255,255,0>[Helios]</color> Deciding to embrace the fact accuracy had to be sacrificed, Helios' engineers sought to make an augment that would prove attractive to both professional atheletes and style-over-substance mercenaries."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 30000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 20,
["end"] = 0,
["perception"] = 0,
["str"] = 20,
["accuracy"] = -20,
}