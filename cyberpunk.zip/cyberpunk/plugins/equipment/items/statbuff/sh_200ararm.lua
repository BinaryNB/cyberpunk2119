ITEM.name = "[R ARM] 200-A Right Arm"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> An improvement on the 100-A, the 200 arm is great for everyday tasks. It's housing is a little thicker, and it's been optimized to not consume so much power."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "x"
ITEM.price = 40
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = 1,
	["end"] = 1,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}