ITEM.name = "[R ARM] 'Curse I' Right Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> Basically a contact taser at your fingertips. Can also connect prehensile nodes from the wrist to a conductive melee weapon to shock whatever is struck. Stuns robotics/augments/devices for one turn if the charge contacts their functional components. Stuns humans too, if you can get the blade/your fingers to their skin or light clothing. After firing, passively takes 2 of your own turns to recharge."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = 5,
	["accuracy"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}