ITEM.name = "[R ARM] Molotok Right Arm"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=255,0,0>[Vissei Concern]</color> The power of the Soviet Union fuels this extremely bulky, extremely heavy Industrial arm. It can't get slower than this, but it also can't get stronger."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "x"
ITEM.price = 450
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = -5,
	["str"] = 25,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}