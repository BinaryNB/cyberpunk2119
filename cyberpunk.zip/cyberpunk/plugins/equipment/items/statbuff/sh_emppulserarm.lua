ITEM.name = "[R ARM] RVA Pulse Right Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color>A new contender for augments, the RVA Pulse arms do not offer much of an advantage in strength, speed, or accuracy. Their strength comes from the fact that they have EMP plating and an integrated EM Pulse device, allowing you to point and disable an individual's augs for a turn."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "x"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["accuracy"] = 5,
}
