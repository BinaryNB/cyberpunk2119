ITEM.name = "[IMPLANT] 'Hyena I' Visual Sound Wave Triangulator"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> This implant allows you to see the approximate origin and location of any sound that differs from the surrounding environment. Fully accurate within' the same room and in 25 meters, though doorways, walls and different materials will instead show a warning hue to whatever entrance the sound is coming through. Also works as extreme ear-protection. Can be countered by not moving, moving silently, and purposely making funky sounds at other locations."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "X"
ITEM.price = 2000
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}