ITEM.name = "[L ARM] 200-A/SPT"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> A relatively simple augment for the outdoor enthusiast, this augment includes a thirty foot spool of rappelling line, with the ability to load a grappling hook to climb an elevated rock face."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 1500
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {
["str"] = 5,
["accuracy"] = 5,
}
