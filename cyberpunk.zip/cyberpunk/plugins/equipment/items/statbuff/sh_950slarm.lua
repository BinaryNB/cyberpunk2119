ITEM.name = "[L ARM] 950-S Left Arm"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=175,0,255>[Aetherstone]</color> The peak of Aetherstone's security augmentation line, these limbs are most typically found attached to the ASF's top-tier Max-Tac operators."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 100000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 25,
["end"] = 0,
["perception"] = 0,
["str"] = -25,
["accuracy"] = 25,
}