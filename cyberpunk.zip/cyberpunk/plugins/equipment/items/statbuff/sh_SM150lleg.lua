ITEM.name = "[L LEG] SM-150 Left Leg"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=100,250,180>[TriTek]</color> TriTek's initial ventures into hybridizing augments proved to offer significant issues in the matter of balancing hardened casings and powerful hydraulics while providing space for kinetic dampeners to assist in recoil control."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftleg" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -10,
["end"] = 10,
["perception"] = 0,
["str"] = 20,
["accuracy"] = -10,
}