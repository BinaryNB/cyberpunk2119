ITEM.name = "[L ARM] 700-Z Left Arm"
ITEM.desc = "<color=225,255,0>[Performance Grade]</color><color=175,0,255>[Aetherstone]</color> The newest arm released by Aetherstone Industries. The 700-Z is the arm of luxury. Geared towards physical performance, the 700-Z is fit for great speed, and is the most highly anticipated performance augment on the market. Unfortunately, it's greatest criticism is that while it has amazing speed, it lacks heavily in strength."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "x"
ITEM.price = 2700
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = 15,
	["str"] = -5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}