ITEM.name = "[L ARM] 'Bhaalgorn I' Left Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> This augment features a hidden arm bay full of micro-spider drones and a semi-prehensile three meter long proboscis. When the proboscis is inserted into the torso of a recently killed/dying biological target, it will surgically rend, tear and feed a steady stream of gore to the arm, which is then carried by the spider drones whom will travel the users body, surgically applying the matter in whatever way possible to stop any bleeding and making it look like new. This is a very inefficient manner of healing wounds, requiring a whole torso per wound. Only provides first aid to wounds, incapable of anything like surgery or removing bullets."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "X"
ITEM.price = 4500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["end"] = 10,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}