ITEM.name = "[L ARM] 'Coercer I' Left Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> Ever looked at your biceps and wished they were guns? Well, now you can! This arm has all the housings for adapting any one-handed firearm into a retractable arm-gun, doing away with any useless grips and the like. Great for hiding firearms in your new firearms! You must go to a ripper-doc every time you intend to install or uninstall a firearm into this augment."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["accuracy"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}