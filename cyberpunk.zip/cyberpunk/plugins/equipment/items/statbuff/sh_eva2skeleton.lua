ITEM.name = "[IMPLANT] EVA-2 Skeleton"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=100,250,180>[Tri-Tek]</color> A Tri-Tek skeleton specifically designed to whether the rigours of space; the density, however, makes it an absolute pain to move with."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -10,
["end"] = 15,
["str"] = 1,
["accuracy"] = 1,
}
