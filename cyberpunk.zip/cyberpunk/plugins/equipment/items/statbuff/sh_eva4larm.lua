ITEM.name = "[L ARM] EVA-4 Left Arm"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=100,250,180>[Tri-Tek]</color> A Tri-Tek limb developed for workers in EVA environments who’ve undergone full-body conversion, this limb has an inbuilt magnet designed to keep one’s body held against space ship hulls. Or to just climb up a fucking building.."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 3000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -5,
["end"] = 10,
["str"] = 5,
["accuracy"] = -2,
}
