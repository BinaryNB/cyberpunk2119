ITEM.name = "[R LEG] PM-5 Right Leg"
ITEM.desc = "<color=225,255,0>[Performance Grade]</color><color=100,250,180>[TriTek]</color> A TriTek model performance limb that is slower than other performance limbs, but certainly stronger. It's casing is designed to look like the muscular system."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg"
ITEM.flag = "x"
ITEM.price = 300
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["str"] = 5,
	["stm"] = 10,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}