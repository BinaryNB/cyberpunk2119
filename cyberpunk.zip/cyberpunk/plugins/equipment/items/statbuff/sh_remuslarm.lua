ITEM.name = "[L ARM] Remus-20H"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=255,255,0>[Helios]</color> Derived from one of Helios' many ventures into applying their skill with droids to humans, the Remus series suffers from a few problems stemming from the fact that humans are very much not like droids."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 20,
["end"] = -10,
["perception"] = 0,
["str"] = 10,
["accuracy"] = -10,
}