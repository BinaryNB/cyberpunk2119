ITEM.name = "[L ARM] 'Cyno I' Left Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> Designed for law enforcement short on numbers, this augmentation contains a chamber packed full of IR smoke and teargas - able to be unsealed almost instantly to cloud the user in smoke, and infusing the smoke with the properties of teargas to any whom might be inside it. Does not protect the user from any of these. Can only be activated once every thirty minutes as it must take the time to remake and fill the chamber with the compound."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["str"] = 5,
	["accuracy"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}