ITEM.name = "[IMPLANT] Caretaker Combat Health System"
ITEM.desc = "<color=100,250,180>[TriTek]</color> A multitude of implants that are distributed along the body. Sensors and probes are connected to most, if not all of the major organs and provide data to a central unit. This unit tracks the condition of these organs and the user as a whole, and proceed to stimulate by use of chemicals and micro-charges in order to effectively greaten the human body’s healing ability. <color=127,255,0>Capable of stabilizing lethal, major injuries such as critical organ damage and limb loss. Regeneration begins thirty seconds after trauma is experienced.</color>"
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 75000
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}
