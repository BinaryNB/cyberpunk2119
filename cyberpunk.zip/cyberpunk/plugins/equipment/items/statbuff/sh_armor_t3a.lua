ITEM.name = "Tier 3A Vest"
ITEM.desc = "Concealable, lightweight, and thin. Overall an attractive choice for 'protection while remaining incognito.' Corporate representatives will often wear IIIA rated vests under their suit blazers, due to the low profile they have. Can also be used as premium armor for the extremities.\nProtection rating: Up to .500 Magnum, 300gr FMJ, 1,700 ft/s."
ITEM.model = "models/gs3/test/i_zur_combatfleece.mdl"
ITEM.buffCategory = "chest"
ITEM.flag = "3"
ITEM.price = 1200
ITEM.category = "Body Armor"

ITEM.salvItem = {
	["j_scrap_cloth"] = 10
}

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}

ITEM.functions.Equip = {
	onRun = function(item)
		item.player:SetArmor(75)
	item.player:EmitSound("items/suitchargeok1.wav")
	item.player:ChatPrint(table.Random(effectText))
	end
}
