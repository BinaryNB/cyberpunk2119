ITEM.name = "[IMPLANT] Grade 2 Reinforced Skeleton"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> An improved version of Aetherstone’s reinforced skeleton, for those who get smacked around an even more regular basis."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -1,
["end"] = 10,
}
