ITEM.name = "[R LEG] Romulus-40H"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=255,255,0>[Helios]</color> While casing integrity was improved with the Romulus series, it was found that aim assistance had to be sacrificed to support both the improved strength and speed integral to the design."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 15000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 20,
["end"] = -5,
["perception"] = 0,
["str"] = 15,
["accuracy"] = -15,
}