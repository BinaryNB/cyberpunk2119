ITEM.name = "Industrial Exoskeleton"
ITEM.desc = "Heavy industrial exo-skeleton frames used by labor workers. Industrial suits can support a huge weight load and heavily improve the wearers strength. The average max weight load for most industrial suits is anywhere from a 1000-1500lbs. These suits however are extremely bulky, and heavily hinder mobility to the point where running is impossible.\nMaterials used: Industrial steel alloys, aluminum, strong servos & aftermarket electronics"
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "4"
ITEM.price = 6500
ITEM.category = "Exo-skeletons"

ITEM.salvItem = {
	["j_scrap_metal"] = 10
}

ITEM.attribBoosts = {
	["stm"] = -25,
	["str"] = 25,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}