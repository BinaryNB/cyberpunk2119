ITEM.name = "[IMPLANT] Lightened Skeleton"
ITEM.desc = "<color=225,255,0>[Performance Grade]</color><color=100,250,180>[TriTek]</color> A rather curious product from TriTek, these lightened bone systems are much lighter than a human’s, allowing for increased acrobatic ability, at the cost of the ability to absorb trauma as extreme as a natural bone system could."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 1500
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 15,
["end"] = -3,
}
