ITEM.name = "[IMPLANT] 'Chaos I' Local Network Scrambler"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> Grants the user the ability to release a mess of electromagnetic signals in the local vicinity, making radios emit a jumble of static while active, interfering with net based communications, and jamming wireless signal based IFF systems. This device does not determine friend from foe either, funny enough. Emits a constant crackle of static from the user, but works within' 25 meters sphere around them with an on/off toggle."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "X"
ITEM.price = 4800
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}