ITEM.name = "[IMPLANT] 'Astero I' Neural Drone Uplink"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> The Astero is a nano drone system that interfaces with neuralware and cyberoptics, allowing the user to literally expunge their eyes in a small housing and deploy them into a drone with a range of 30 meters. Can use all your neuralware and cybernetics from the drones position."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}