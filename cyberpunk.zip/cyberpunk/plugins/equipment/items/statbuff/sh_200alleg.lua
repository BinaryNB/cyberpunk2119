ITEM.name = "[L LEG] 200-A Left Leg"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> Aetherstone's improved cybernetic leg. It's more durable and has optimization for minimal strain on the user."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftleg"
ITEM.flag = "x"
ITEM.price = 40
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = 1,
	["end"] = 1,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}