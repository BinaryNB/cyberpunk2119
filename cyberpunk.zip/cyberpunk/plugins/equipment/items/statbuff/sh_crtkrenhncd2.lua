ITEM.name = "[IMPLANT] Enhanced Caretaker Delivery System"
ITEM.desc = "<color=100,250,180>[TriTek]</color> A supplementary, after-market upgrade to TriTek's caretaker system that accelerates the beginning of the regeneration process. <color=127,255,0>Reduces the time to begin regeneration to 20 seconds.</color>"
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 30000
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}
