ITEM.name = "Kevlar Soft Vest"
ITEM.desc = "Cheap and affordable soft body armor made from kevlar. These can be easily worn under clothes, and is currently most commonly incorporated in tunics, trousers, and jackets. \nProtection rating: Up to .45 ACP, 215gr FMJ, 835 ft/s."
ITEM.model = "models/gs3/test/i_zur_combatleather.mdl"
ITEM.buffCategory = "chest"
ITEM.flag = "3"
ITEM.price = 400
ITEM.category = "Body Armor"

ITEM.salvItem = {
	["j_scrap_cloth"] = 10
}

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}

ITEM.functions.Equip = {
	onRun = function(item)
		item.player:SetArmor(50)
	item.player:EmitSound("items/suitchargeok1.wav")
	item.player:ChatPrint(table.Random(effectText))
	end
}
