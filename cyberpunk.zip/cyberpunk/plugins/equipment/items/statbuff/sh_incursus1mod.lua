ITEM.name = "[MOD] 'Incursus I' Neural Subsystem"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> The Incursus from IO is a modification that renders pain as something non-debilitating, controls the release of adrenaline to maintain the users accuracy, and slightly dulls the effects of combat stress. 87 percent of all users of this mod bleed out as they misjudge the severity of their wounds and push their body to keep going until death, making their injuries far worse in the process. Accelerates the onset of cyberpsychosis by 2x, doubling the need from all augmentations."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "neuralware"
ITEM.flag = "X"
ITEM.price = 3800
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}