ITEM.name = "CHIMERA-2"
ITEM.desc = "<color=175,0,255>[Aetherstone]</color><color=0,175,255>[Security Grade/Police Grade]</color> The Chimera series is Aetherstones direct answer to the recent corporate wars that rage within Metropolis-1 and Japan as a whole. The newest upgrade to the Chimera-2 over its predecessor is its improved servos and hardened outer frame. Marksmanship with this exosuit will prove to be quite difficult without the right augments to offset the disadvantage. Materials used: Steel alloys, aluminum, lightweight servos & advanced electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 65000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = 10,
["str"] = 9,
["end"] = 8,
["acc"] = -2,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}