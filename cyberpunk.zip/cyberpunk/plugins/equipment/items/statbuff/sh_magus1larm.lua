ITEM.name = "[L ARM] 'Magus I' Left Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> A brutish robust arm sporting a miniature, high-pressure flame jet with a range of 1 meter. Can fire (yes, fire) for a solid eight seconds (4 shots) before the tank needs to be refilled."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "X"
ITEM.price = 1800
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["str"] = 10,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}