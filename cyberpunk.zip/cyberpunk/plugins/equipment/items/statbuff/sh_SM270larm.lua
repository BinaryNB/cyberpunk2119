ITEM.name = "[L ARM] SM-270 Left Arm"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=100,250,180>[TriTek]</color> Accuracy problems solved, the 270 series represents TriTek coming into their own as a producer of strong, durable augments, even if they are on the slow side."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 30000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -20,
["end"] = 20,
["perception"] = 0,
["str"] = 20,
["accuracy"] = 0,
}