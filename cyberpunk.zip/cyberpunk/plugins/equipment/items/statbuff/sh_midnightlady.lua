ITEM.name = "[IMPLANT] Tier One Midnight Lady"
ITEM.desc = "<color=255,127,223>[Mia Khalifa Industries]</color> A cybernetic vagina. Initially a 'tier one' each tier equates to two inches of depth. This item can be upgraded by a cyberneticist for two thousand credits per tier (at a minimum). Highly modifiable."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "cunt" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}
