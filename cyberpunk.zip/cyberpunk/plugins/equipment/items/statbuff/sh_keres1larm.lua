ITEM.name = "[L ARM] 'Keres I' Left Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> The Keres arm systems are peculiar to look at - rounded stained transparent polymer being the main housing making them easy to recognize. It features the ability to be suddenly flashed, emitting an incredibly bright light and loud bang akin to a flashbang from the users arm. Will not protect the users eyes or ears. Doubles as a short range lamp-light for dark situations. Contains two charges, with one charge returning every four turns."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["end"] = 5,
	["accuracy"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}