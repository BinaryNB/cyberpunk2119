ITEM.name = "[L ARM] 800-Z Left Arm"
ITEM.desc = "<color=225,255,0>[Performance Grade]</color><color=175,0,255>[Aetherstone]</color> In typical Aetherstone fashion, the 800-Z ignores every complaint forwarded about the 700-series' strength issues to instead turn every man into his own personal ground car. It's eco-friendly transportation!"
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 450
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 25,
["end"] = 0,
["perception"] = 0,
["str"] = -10,
["accuracy"] = 0,
}