ITEM.name = "[EYES] 'Huginn I' Cyberoptics"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> Augmented Reality Cyber-optics that can 'paint' a target, transmitting an image of it to other AR optics in 3D space. Useful for wallbanging some shithead trying to hold you up with the help of friends."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "cybereyes"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["perception"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}