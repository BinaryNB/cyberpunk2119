ITEM.name = "[R ARM] 'Proteus I' Right Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> A fairly powerful arm that includes a full suite of configurable precision multitools that extend from the arm, palm, and fingertips. Basically a toolbox in your arm. Great for tinkerers and doctors, as different tools can be used seperately in the same local area around the arm all at the same time!"
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["str"] = 5,
	["accuracy"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}