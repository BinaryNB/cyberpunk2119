ITEM.name = "[L ARM] 100-A Left Arm"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> Aetherstone's first cybernetic limb, the 100-A arm is great for everyday tasks. They have a thin plastic housing, meaning it's exposed to wear, but it's very cheap."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "x"
ITEM.price = 25
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {

}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}