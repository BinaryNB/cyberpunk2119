ITEM.name = "Tier 3 Composite Arm Protectors"
ITEM.desc = "The most common and modern form of plate armor, composite armor is lightweight nano-structured polymers with a thin ceramic laminate. This plate is light enough to be worn with a full suit without augmentation, however they have limited durability and can only withstand so much before the plate is ruined.\nProtection rating: Rated to stop up to .308 150gr FMJ, 2,733 ft/s."
ITEM.model = "models/gs3/test/i_hands_combatgloves.mdl"
ITEM.buffCategory = "arms"
ITEM.flag = "5"
ITEM.price = 3000
ITEM.category = "Body Armor"

ITEM.salvItem = {
	["j_scrap_cloth"] = 10
}

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}
