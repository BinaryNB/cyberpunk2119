ITEM.name = "[R ARM] 'Crusader I' Right Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> An arm that turns into a crossbow, the entire top half of forearm splitting aside into limbs and presenting a sled from which you can put bolts, arrows, darts and even some other things on to launch them at people. Can be preloaded with standard bolts. Takes no turn to deploy, but does to reload, or to fire."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["accuracy"] = 10,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}