ITEM.name = "[IMPLANT] 'Gemini I' Synchronization Matrix"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> An implant that when paired with another of the same kind, allows both users to synchronize actions perfectly between them - taking a shot at the same time, performing a dance move in tandem, synchronizing movement between a ballistic shield pointman to his battlebuddy with a rifle.. the possibilities are endless, though it's difficult to make these things work outside entertainment."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "X"
ITEM.price = 750
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}