ITEM.name = "[R ARM] Guardian Right Arm"
ITEM.desc = "<color=255,0,0>[Military Grade]</color><color=0,255,240>[Aegis Unlimited]</color> A popular choice by security and military, Aegis Guardians are extremely durable, to the point that they can withstand an incredible amount of damage from bullets, pressure and shock all at once due to it's incredibly advanced housing and internals. You could get run over by a truck and still be fine with one of these. A big enough bullet will still shred through these if they're shot enough, though. (Equivalent to NIJ Level III plating.)"
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "X"
ITEM.price = 15000
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["end"] = 25,
}


ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}