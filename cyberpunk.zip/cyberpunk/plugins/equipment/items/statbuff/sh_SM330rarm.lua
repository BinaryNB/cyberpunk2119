ITEM.name = "[R ARM] SM-330 Right Arm"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=100,250,180>[TriTek]</color> TriTek's last generation hybrid augment, these are only a step below the 360 series in terms of their case strength."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 75000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -25,
["end"] = 20,
["perception"] = 0,
["str"] = 25,
["accuracy"] = 0,
}