ITEM.name = "[EYES] Omega Recon Eyes"
ITEM.desc = "<color=175,255,0>[Omega Global]</color> Security Grade cyberoptics fitted with telescopic vision and image enhancement for <color=175,255,0>low light conditions</color> and far off images. Unfortunately, these eyes are <color=255,0,0>incompatible with SmartLink</color>, and suffer from a slight decrease in accuracy."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "cybereyes"
ITEM.flag = "x"
ITEM.price = 700
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["perception"] = 15,
	["accuracy"] = -10,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}