ITEM.name = "Tier 2 Helmet"
ITEM.desc = "Cheap and affordable soft body armor made from kevlar. These can be easily worn under clothes, and is currently most commonly incorporated in tunics, trousers, and jackets, to offer additional ballistic protection against shrapnel. The most ordered type of Level II rated armor in Metropolis-1 is concealable armor. \nProtection rating: Up to .45 ACP, 215gr FMJ, 835 ft/s."
ITEM.model = "models/gs3/test/i_helmet_1.mdl"
ITEM.buffCategory = "head"
ITEM.flag = "3"
ITEM.price = 250
ITEM.category = "Body Armor"


ITEM.salvItem = {
	["j_scrap_cloth"] = 10
}

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}

