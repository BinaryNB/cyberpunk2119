ITEM.name = "[R LEG] 750-S Right Leg"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=175,0,255>[Aetherstone]</color> With their casing issue solved by this generation, Aetherstone's hybrid line became a viable choice for many security forces who had problems requiring QRF operators."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 30000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 20,
["end"] = 0,
["perception"] = 0,
["str"] = -20,
["accuracy"] = 20,
}