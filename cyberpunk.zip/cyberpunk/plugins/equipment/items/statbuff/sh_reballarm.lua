ITEM.name = "[L ARM] ReBalance Left Arm"
ITEM.desc = "A good re-imbursement augment for people who've lost their limbs to software updates. Well rounded."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "x"
ITEM.price = 1000
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["end"] = 7,
	["accuracy"] = 7,
	["stm"] = 7,
	["str"] = 7,
}
