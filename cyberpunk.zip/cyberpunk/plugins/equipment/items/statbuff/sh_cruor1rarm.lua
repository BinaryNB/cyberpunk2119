ITEM.name = "[L ARM] 'Cruor I' Right Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> IO's first big hit augmentation, likely made to appeal to the thugs that would eventually buy them. Looks for the most part like your run of the mill aug, however hides motorized extend-able mantis blades that can strike out at a moments notice. Can be refit with higher quality blades, but by default only comes with standard steel."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm"
ITEM.flag = "X"
ITEM.price = 1500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = 5,
	["str"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}