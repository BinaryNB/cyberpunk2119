ITEM.name = "GURU-1"
ITEM.desc = "<color=0,255,0>[PackCorp]</color><color=225,255,0>[Hybrid]</color> A new competitor in the exo-skeleton market, advertised to all demographic for its ease of access, affordability, and general usage across the board. Moreover, this model is designed to be highly customizable. Materials used: Steel alloys, aluminum, lightweight servos & aftermarket electronics."
ITEM.model = "models/gs3/test/i_exo_light.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 25000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["end"] = 10,
["str"] = 10,
["stm"] = 10,
["acc"] = 5,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}