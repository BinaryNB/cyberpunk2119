ITEM.name = "RANGER"
ITEM.desc = "<color=255,255,0>[United Navigations Nominate]</color><color=255,0,0>[Military Grade]</color> The Ranger series is the newest exoskeleton issued to UNN troopers. EMP resistance included. Materials used: Armored steel alloys, aluminum, strengthened servos & advanced electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "B"
ITEM.price = 1250000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = 25,
["str"] = 10,
["acc"] = 25,
["end"] = 20,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}