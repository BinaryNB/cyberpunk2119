ITEM.name = "HUNTER-1"
ITEM.desc = "<color=0,175,255>[Security Grade/Police Grade]</color><color=100,250,180>[TriTek]</color> The Hunter series is the newest TriTek exo-skeletons to release with the recent corporate war with ASF TriTek has improved what was once an old generation police exo to a modern fighting standards. A balanced choice. Materials used: Steel alloys, aluminum, lightweight servos & advanced electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 19000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = 10,
["str"] = 15,
["acc"] = 15,
["end"] = -5,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}