ITEM.name = "[L ARM] EVA-2 Left Arm"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=100,250,180>[Tri-Tek]</color> A Tri-Tek limb developed for workers in EVA environments, this limb has an inbuilt magnet designed to keep one’s body held against space ship hulls. Or to just climb up a fucking building.."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 1500
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 1,
["end"] = 5,
["str"] = 2,
["accuracy"] = 1,
}
