ITEM.name = "[IMPLANT] Reinforced Skeleton"
ITEM.desc = "<color=175,0,255>[Aetherstone]</color> Reinforced skeletons provide the ability to absorb shock with a high grade of durability. Perfect for those who get beat on a daily basis."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "x"
ITEM.price = 1500
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
	["end"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}