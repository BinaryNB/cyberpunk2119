ITEM.name = "[R ARM] 850-S Right Arm"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=175,0,255>[Aetherstone]</color> Aetherstone's last-generation hybridized augment, the only thing inferior aspect to the 950-S is in regards to its agility."ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 75000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 20,
["end"] = 0,
["perception"] = 0,
["str"] = -25,
["accuracy"] = 25,
}