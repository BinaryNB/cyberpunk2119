ITEM.name = "AEOLUS-1"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=100,250,180>[TriTek]</color> An effort to match performance-grade limbs in the form of an exoskeleton. Cheaper and augments the user's speed entirely through its servos unlike limbs. Similar to that of said limbs. While very much lacking in durability due to its weak material, it makes for good sporting use. Materials used: Polymer plastics and aluminum, weak servos & cheap electronics."
ITEM.model = "models/gs3/test/i_exo_light.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 500
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = 5,
["end"] = -5,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}