ITEM.name = "[R LEG] Remus-20H"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=255,255,0>[Helios]</color> A by-product of Helios’ ADAM project, these legs combine strength and speed to produce a truly impressive combat capability. Just don’t try and fire a demounted mini-gun with these alone."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 20,
["end"] = -10,
["perception"] = 0,
["str"] = 10,
["accuracy"] = -10,
}