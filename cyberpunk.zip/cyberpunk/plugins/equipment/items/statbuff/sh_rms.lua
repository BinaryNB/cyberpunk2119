ITEM.name = "[MOD] Responsive Modulator System"
ITEM.desc = "<color=175,0,255>[Aetherstone]</color> An implant that directly influences your nervous system and acts as a supercharger to increase your reflexes and ability."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "neuralware"
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
	["str"] = 1,
	["stm"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}