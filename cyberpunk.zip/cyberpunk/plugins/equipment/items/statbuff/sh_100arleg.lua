ITEM.name = "[R LEG] 100-A Right Leg"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> Aetherstone's first model cybernetic leg. It's a cheap, thin limb in a plastic housing, which works well in a normal setting."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg"
ITEM.flag = "x"
ITEM.price = 25
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {

}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}