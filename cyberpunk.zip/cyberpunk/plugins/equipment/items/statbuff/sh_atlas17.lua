ITEM.name = "ATLAS-17"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=255,255,0>[Helios]</color> Helios' first steps into the industrial exo-skeleton market has changed the game with the ATLAS-17 able to lift heavier objects while also having more freedom then its competitors. Materials used: Industrial steel alloys, aluminum, strong servos & aftermarket electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 7500
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = -20,
["str"] = 20,
["end"] = 10,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}