ITEM.name = "Civilian Exoskeleton"
ITEM.desc = "<color=170,170,210>[Various Companies]</color> Civilian grade exo-skeletons are often used by the crippled who couldn't afford multiple limb replacements. They support the body and can carry a limited additional weight of anywhere from 70 to 120lbs. This ironically makes them good as cheap cop-outs for alloy armor housings, if anyone is able to come across them nowadays."
ITEM.model = "models/gs3/test/i_exo_light.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 50
ITEM.category = "Exo-skeletons"

ITEM.salvItem = {
	["j_scrap_metal"] = 10
}
ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}