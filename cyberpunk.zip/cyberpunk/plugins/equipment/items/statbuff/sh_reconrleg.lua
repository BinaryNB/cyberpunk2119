ITEM.name = "[R LEG] Omega Recon Right Leg"
ITEM.desc = "<color=225,255,0>[Performance Grade]</color><color=175,255,0>[Omega Global]</color> A pair of performance grade cybernetic limbs. They're thin, skeletonized legs that are similar to old running blade prosthetics. They're incredibly efficient and as stable as can be, as well as maintain a great degree of speed, but suffer from being easy to break."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg"
ITEM.flag = "x"
ITEM.price = 500
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = 15,
	["accuracy"] = 5,
	["end"] = -5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}