ITEM.name = "[R ARM] 650-S Right Arm"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=175,0,255>[Aetherstone]</color> Another limb from a few generations back, this one with slightly less of a casing issue-- but showing Aetherstone's aligning towards speedy, precise augmentation."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 15000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 15,
["end"] = -5,
["perception"] = 0,
["str"] = -15,
["accuracy"] = 20,
}