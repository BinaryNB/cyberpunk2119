ITEM.name = "PROCTOR-1 Exoskeleton"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=100,250,180>[TriTek]</color> The Proctor-1 is a mass-produced civilian grade exo-skeleton often used to assist with labor with ease. Nothing like the industrial grade exo-skeleton, but much cheaper and easier to access. Materials used: Polymer plastics and aluminum, weak servos & cheap electronics."
ITEM.model = "models/gs3/test/i_exo_light.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 500
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["end"] = -1,
["str"] = 5,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}