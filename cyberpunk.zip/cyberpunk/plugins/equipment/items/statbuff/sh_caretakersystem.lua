ITEM.name = "[IMPLANT] Caretaker Health System"
ITEM.desc = "<color=100,250,180>[TriTek]</color> A multitude of implants that are distributed along the body. Sensors and probes are connected to most, if not all of the major organs and provide data to a central unit. This unit tracks the condition of these organs and the user as a whole, and proceed to stimulate by use of chemicals and micro-charges in order to effectively greaten the human body’s healing ability."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "x"
ITEM.price = 1500
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}