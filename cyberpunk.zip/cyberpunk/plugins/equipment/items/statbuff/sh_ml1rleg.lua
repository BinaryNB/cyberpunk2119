ITEM.name = "[R LEG] ML-1 Right Leg"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=100,250,180>[TriTek]</color> A basic civilian grade augment. It's fairly functional, and has a sturdy enough housing to withstand some weather, for a cheap price tag too."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "rightleg"
ITEM.flag = "x"
ITEM.price = 35
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["end"] = 1,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}