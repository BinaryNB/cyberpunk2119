ITEM.name = "[L ARM] SM-210 Left Arm"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=100,250,180>[TriTek]</color> Sporting some rudimentary recoil dampeners, the 210 series still suffers from calibration issues that make them sub-par choices to more recent generations, but still viable to those on a budget.."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 15000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -15,
["end"] = 15,
["perception"] = 0,
["str"] = 20,
["accuracy"] = -5,
}