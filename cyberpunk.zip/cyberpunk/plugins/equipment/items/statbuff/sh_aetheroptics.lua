ITEM.name = "[EYES] Aetherstone Cyberoptics"
ITEM.desc = "<color=175,0,255>[Aetherstone]</color> Civilian grade cybernetic eyes that offer some enhancements to vision, as well as the inclusion of <color=175,0,255>teleoptics</color>."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "cybereyes"
ITEM.flag = "x"
ITEM.price = 40
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {
	["perception"] = 5,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}