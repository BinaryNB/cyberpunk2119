ITEM.name = "[L ARM] 550-I Left Arm"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=175,0,255>[Aetherstone]</color> An industrial arm by Aetherstone. It's large and powerful, and can probably lift a car, but lacks in the speed department to most, if not all augments."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "x"
ITEM.price = 300
ITEM.category = "Cybernetics"

ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = -5,
	["str"] = 15,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}