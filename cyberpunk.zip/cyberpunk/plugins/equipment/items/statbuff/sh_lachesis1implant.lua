ITEM.name = "[IMPLANT] 'Lachesis I' Electronic Signature Disruption Suite"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> The Lachesis ESDS full suite implant provides the user with protection from different electronic warfare attacks aswell as detection, stifling remote hack attempts immediately aswell as preventing target painting, system scans, and radar detection. NOTE: You CANNOT hack while this implant is installed."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "X"
ITEM.price = 3500
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}