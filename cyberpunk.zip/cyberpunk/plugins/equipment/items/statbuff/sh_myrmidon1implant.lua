ITEM.name = "[IMPLANT] 'Myrmidon I' Respiratory Rebreather Reinforcement"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> The Myrmidon 'RRR' implant allows the user to breathe indefinitely underwater, aswell as resist any aerosol/gas based attacks on the respiratory system. Will not stop manners of gas that literally burn your skin off."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "X"
ITEM.price = 2000
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}