ITEM.name = "[L LEG] IR-10 Left Leg"
ITEM.desc = "<color=255,100,0>[Industrial Grade]</color><color=100,250,180>[TriTek]</color> A TriTek model industrial limb boasting a fair amount of strength. It's rather big and bulky, but that's normal for industrial limbs."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftleg"
ITEM.flag = "x"
ITEM.price = 300
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["stm"] = -2,
	["str"] = 10,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}