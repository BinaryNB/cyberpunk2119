ITEM.name = "HUNTER-2"
ITEM.desc = "<color=0,175,255>[Security Grade/Police Grade]</color><color=100,250,180>[TriTek]</color> The Hunter-2 has been enhanced with more stable alloys to assist with precision shooting even further, alongside upgraded servos to increase the user's motor functions."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 65000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = 9,
["str"] = -2,
["end"] = 8,
["acc"] = 10,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}