ITEM.name = "[MOD] JoyCo. DataLink"
ITEM.desc = "<color=240,100,240>[JoyCo.]</color> An implant that automatically connects to and processes things on the net. Can be controlled mentally."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "neuralware"
ITEM.flag = "x"
ITEM.price = 500
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}