ITEM.name = "[IMPLANT] Tier One Mister Studd"
ITEM.desc = "<color=29,255,255>[Ron Jeremy Corp]</color> A cybernetic penis. Initially a 'tier one' each tier equates to two inches. This item can be upgraded by a cyberneticist for two thousand credits per tier (at a minimum). Highly modifiable."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "dick" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 0,
["end"] = 0,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}
