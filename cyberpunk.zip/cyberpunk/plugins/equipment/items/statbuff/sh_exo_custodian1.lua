ITEM.name = "CUSTODIAN-1"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> Specialized civilian-grade exoskeleton recently released into the public and marketed in dangerous areas for its durability over other exoskeletons of the same level. Materials used: Hardened polymer plastics and aluminum, weak servos & cheap electronics."
ITEM.model = "models/gs3/test/i_exo_light.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 500
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["end"] = 5,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}