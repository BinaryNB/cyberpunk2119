ITEM.name = "CUSTODIAN-2"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> [Aetherstone] An enhanced version of its predecessor. Often used by lesser companies unable to afford security level equipment, this model possesses good durability and stability. Materials used: Hardened plastics and aluminum, industrial servos & cheap electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "4"
ITEM.price = 1000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["end"] = 5,
["acc"] = 5,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}