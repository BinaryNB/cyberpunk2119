ITEM.name = "Stab Vest"
ITEM.desc = "A fully conealable and discreet NIJ Level I stab resistant vest that can fit under clothing and protects from bladed weapons. Also protects from needles and some blunt force."
ITEM.model = "models/tnb/items/shirt_rebel1.mdl"
ITEM.buffCategory = "chest"
ITEM.flag = "3"
ITEM.price = 100
ITEM.category = "Body Armor"

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}

ITEM.functions.Equip = {
	onRun = function(item)
		item.player:SetArmor(5)
	item.player:EmitSound("items/suitchargeok1.wav")
	item.player:ChatPrint(table.Random(effectText))
	end
}
