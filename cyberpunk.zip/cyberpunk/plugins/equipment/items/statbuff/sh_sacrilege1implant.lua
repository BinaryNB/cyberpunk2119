ITEM.name = "[IMPLANT] 'Sacrilege I' Extreme Trauma Reduction Kit"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=224,2,95>[Intellectual Outcomes]</color> The Sacrilege ETRK implant kit is more or less a full body reinforcement of padding that helps drastically against blunt force. It wont stop any bullets or stabs on it's own, but it'll prevent your insides being mushed up when your tier 2 stops a 12g from penetrating, or your tier 4 stops a .50 BMG. Slows the user down a lot, but it's the price you pay if you want to be truly bullet proof."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant"
ITEM.flag = "X"
ITEM.price = 6400
ITEM.category = "Implants and Mods"
ITEM.cyber = true

ITEM.attribBoosts = {
["stm"] = -20,
["end"] = 10,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 0,
}


ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}