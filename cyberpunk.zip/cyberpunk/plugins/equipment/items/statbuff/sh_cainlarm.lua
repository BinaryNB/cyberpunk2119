ITEM.name = "[L ARM] Cain-1:8"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=255,255,0>[Helios]</color> A by-product of Helios’ ADAM project, these arms combine strength and speed to produce a truly impressive combat capability. Just don’t try and be a marksman with these. They aren’t meant for it."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 100000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 25,
["end"] = 0,
["perception"] = 0,
["str"] = 25,
["accuracy"] = -25,
}