ITEM.name = "[IMPLANT] Grade 3 Reinforced Skeleton"
ITEM.desc = "<color=0,255,100>[Civilian Grade]</color><color=175,0,255>[Aetherstone]</color> Aetherstone's answer to the age old question of why the chicken crossed the road without being immune to getting hit by a car.."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "implant" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 10000
ITEM.category = "Implants and Mods"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = -3,
["end"] = 15,
}
