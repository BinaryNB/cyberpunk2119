ITEM.name = "SHTURMOVIK"
ITEM.desc = "<color=255,25,0>[Eurasian Union]</color><color=0,175,255>[Security Grade/Police Grade]</color> Eurasia's first widespread security exo-skeleton features state-of-the-art strength and structural integrity allowing users to take a beating while also being able to punch, kick and in general out-lift competitors. Unfortunately, it does not particularly augment the user's speed much. Materials used: Steel alloys, aluminum, lightweight servos & advanced electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl"
ITEM.buffCategory = "exo"
ITEM.flag = "A"
ITEM.price = 65000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = -2,
["str"] = 10,
["end"] = 9,
["acc"] = 8,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}