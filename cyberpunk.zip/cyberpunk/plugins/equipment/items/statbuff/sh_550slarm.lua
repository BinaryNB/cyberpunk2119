ITEM.name = "[L ARM] 550-S Left Arm"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=175,0,255>[Aetherstone]</color> Representing Aetherstone's initial venture into hybridizing augments, the 550-S series suffered from serious problems in regards to its case integrity and strength capabilities.."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 5000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 10,
["end"] = -10,
["perception"] = 0,
["str"] = -10,
["accuracy"] = 20,
}