ITEM.name = "[L LEG] SM-180 Left Leg"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=100,250,180>[TriTek]</color> A TriTek model security limb that has an incredible amount of stability and recoil dampening, designed for use by marksmen."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftleg" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 450
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 0,
["end"] = -10,
["perception"] = 0,
["str"] = 0,
["accuracy"] = 25,
}