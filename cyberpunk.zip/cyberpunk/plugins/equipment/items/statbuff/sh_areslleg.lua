ITEM.name = "[L LEG] Ares-80H"
ITEM.desc = "<color=255,255,0>[Hybrid]</color><color=255,255,0>[Helios]</color> Sporting speed and strength in near-equal value, the Ares series of limbs is meant to impress fighters both on the sports field and the battlefield. As of late, this series has been surpassed by the fruits of the company's ADAM project."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftleg" --(rightleg, leftleg, rightarm, leftarm, cybereyes, neuralware)
ITEM.flag = "x"
ITEM.price = 75000
ITEM.category = "Cybernetics"

ITEM.cyber = true


ITEM.attribBoosts = {
["stm"] = 25,
["end"] = 0,
["perception"] = 0,
["str"] = 20,
["accuracy"] = -25,
}
