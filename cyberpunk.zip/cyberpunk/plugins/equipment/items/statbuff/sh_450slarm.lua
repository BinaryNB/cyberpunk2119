ITEM.name = "[L ARM] 450-S Left Arm"
ITEM.desc = "<color=0,175,255>[Security Grade/LastGen]</color><color=175,0,255>[Aetherstone]</color> Aetherstone's secutiy model cybernetic limb. It features pinpoint accurate movements and limb stability that is almost unrivaled."
ITEM.model = "models/nt/props_office/luggage_suitcase.mdl"
ITEM.buffCategory = "leftarm"
ITEM.flag = "x"
ITEM.price = 300
ITEM.category = "Cybernetics"
ITEM.cyber = true

ITEM.attribBoosts = {
	["str"] = 2,
	["accuracy"] = 15,
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}