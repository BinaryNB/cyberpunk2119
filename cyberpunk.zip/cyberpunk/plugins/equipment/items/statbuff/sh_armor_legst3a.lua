ITEM.name = "Tier 3A Leg Protectors"
ITEM.desc = "Concealable, lightweight, and thin. Overall an attractive choice for 'protection while remaining incognito.' Corporate representatives will often wear IIIA rated armor under their clothes, due to the low profile they have. Can also be used as premium armor for the extremities.\nProtection rating: Up to .500 Magnum, 300gr FMJ, 1,700 ft/s."
ITEM.model = "models/gs3/test/i_nrc_sniperlower.mdl"
ITEM.buffCategory = "legs"
ITEM.flag = "3"
ITEM.price = 500
ITEM.category = "Body Armor"

ITEM.salvItem = {
	["j_scrap_cloth"] = 10
}

ITEM.attribBoosts = {
}

ITEM.iconCam = {
	pos = Vector(0, 5.5, 200),
	ang = Angle(90, 0, 0),
	fov = 8.5,
}

