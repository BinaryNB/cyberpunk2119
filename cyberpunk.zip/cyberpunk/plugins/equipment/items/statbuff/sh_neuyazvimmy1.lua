ITEM.name = "Neuyazvimyy-1"
ITEM.desc = "<color=255,25,0>[Eurasian Union]</color><color=255,0,0>[Military Grade]</color> With the recent wars with Eurasia the country has developed its own exo-skeletons to combat enemy forces. These suits are on par with the RANGER series, except for the fact it is still quite hard to traverse quickly while wearing one. It has more emphasis on durability and lifting strength compared to its UNN counterpart. EMP resistance included. Materials used: Armored steel alloys, aluminum, strengthened servos & advanced electronics."
ITEM.model = "models/gs3/test/i_exo_medium.mdl "
ITEM.buffCategory = "exo"
ITEM.flag = "B"
ITEM.price = 1250000
ITEM.category = "Exo-skeletons"
ITEM.salvItem = {
["j_scrap_metal"] = 10
}
ITEM.attribBoosts = {
["stm"] = 20,
["str"] = 25,
["acc"] = 10,
["end"] = 25,
}
ITEM.iconCam = {
pos = Vector(0, 5.5, 200),
ang = Angle(90, 0, 0),
fov = 8.5,
}