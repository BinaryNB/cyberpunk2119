PLUGIN.name = "Drugs"
PLUGIN.author = "Binary"
PLUGIN.desc = "lol drugs"

