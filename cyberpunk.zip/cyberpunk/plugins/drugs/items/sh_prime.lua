ITEM.name = "Prime"
ITEM.desc = "A thin hypodermic needle filled with liquid euphoria."
ITEM.model = "models/katharsmodels/syringe_out/syringe_out.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Drugs"
ITEM.flag = "z"
ITEM.iconCam = {
	pos = Vector(-123.08602905273, -103.44513702393, 75.04386138916),
	ang = Angle(25, 40, 18.888889312744),
	fov = 2.7777777777778
}

ITEM.price = 10

local effectText = {
	"Your body is telling you that you need more of this stuff. *Right now.* It's making everything feel so good, you're not sure how you lived without it!",
}

ITEM.functions.Use = {
onRun = function(item)
  local drug = ents.Create("durgz_meth")
  drug:SetPos(item.player:GetPos())
  drug:Spawn()
  drug:Use(item.player, item.player, USE_ON, 1)
  item.player:ChatPrint(table.Random(effectText))
  item.player:EmitSound("drugs/pills.wav")
  item.player:ScreenFade(1, Color(255, 255, 255, 255), 3, 0)
end
}

