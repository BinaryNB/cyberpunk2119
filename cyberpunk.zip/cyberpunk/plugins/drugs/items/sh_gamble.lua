ITEM.name = "Gamble"
ITEM.desc = "An odd gamble of pills. Quite literally."
ITEM.model = "models/katharsmodels/contraband/metasync/blue_sky.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.duration = 200
ITEM.category = "Drugs"
ITEM.flag = "z"
ITEM.iconCam = {
	pos = Vector(-200, 0, 0),
	ang = Angle(0, -0, 0),
	fov = 2.7777777777778
}


ITEM.price = 25

local effectText = {
	"Gamble's effects begin quickly, first comes flashing colors, then hallucination. Fifty percent chance it's horrifying nightmare fuel hallucinations, fifty percent chance it's rainbows and happiness. Hope you roll above a fifty.",
}

ITEM.functions.Use = {
onRun = function(item)
  local drug = ents.Create("durgz_pcp")
  drug:SetPos(item.player:GetPos())
  drug:Spawn()
  drug:Use(item.player, item.player, USE_ON, 1)
  item.player:ChatPrint(table.Random(effectText))
  item.player:EmitSound("drugs/pills.wav")
  item.player:ScreenFade(1, Color(255, 255, 255, 255), 3, 0)
end
}

