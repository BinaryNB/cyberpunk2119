ITEM.name = "Rabbit"
ITEM.desc = "An unusually heavy paper package filled with white powder."
ITEM.model = "models/srcocainelab/ziplockedcocaine.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.duration = 200
ITEM.category = "Drugs"
ITEM.flag = "z"
ITEM.attribBoosts = {
	["end"] = 50,
	["stm"] = 50,
}
ITEM.iconCam = {
	pos = Vector(0, 0, 200),
	ang = Angle(90, 0, -180),
	fov = 1.6666666666667
}
ITEM.price = 100
local effectText = {
	"You feel energy coursing through your veins in a great, exhilarating rush as you snort down Rabbit. You need more.",
}

ITEM.functions.Use = {
onRun = function(item)
  local drug = ents.Create("durgz_cocaine")
  drug:SetPos(item.player:GetPos())
  drug:Spawn()
  drug:Use(item.player, item.player, USE_ON, 1)
  item.player:ChatPrint(table.Random(effectText))
  item.player:EmitSound("drugs/cocaine.wav")
  item.player:ScreenFade(1, Color(255, 255, 255, 255), 3, 0)
end
}

