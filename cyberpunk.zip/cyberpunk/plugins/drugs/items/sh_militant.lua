ITEM.name = "Militant"
ITEM.desc = "Militant Combat Stimulant, for when your best needs a little extra!"
ITEM.model = "models/w_models/weapons/w_eq_painpills.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.duration = 200
ITEM.category = "Drugs"
ITEM.flag = "m"
ITEM.iconCam = {
	pos = Vector(-200, 0, 0),
	ang = Angle(0, -0, 0),
	fov = 2.7777777777778
}


ITEM.price = 500

local effectText = {
	"Your ability to feel pain is quickly dulled. Really, your ability to process *any* sensation is fading pretty drastically, just like your field of vision is darkening and leaving you with tunnel vision. You do however, feel rage, and a bit of bloodlust.",
}

ITEM.functions.Use = {
onRun = function(item)
  local drug = ents.Create("durgz_heroine")
  drug:SetPos(item.player:GetPos())
  drug:Spawn()
  drug:Use(item.player, item.player, USE_ON, 1)
  item.player:ChatPrint(table.Random(effectText))
  item.player:EmitSound("drugs/pills.wav")
  item.player:ScreenFade(1, Color(255, 255, 255, 255), 3, 0)
end
}

