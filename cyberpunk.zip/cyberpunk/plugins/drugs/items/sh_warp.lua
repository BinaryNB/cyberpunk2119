ITEM.name = "Warp"
ITEM.model = "models/props_pony/mlp_coin.mdl"
ITEM.desc = "A little cardboard box with a few flat tablets inside."
ITEM.duration = 100
ITEM.price = 35
ITEM.category = "Drugs"
ITEM.flag = "z"
ITEM.iconCam = {
	pos = Vector(-0, 3, 200),
	ang = Angle(90, 0, -180),
	fov = 12.777777777778
}

local effectText = {
	"Moments after taking the tablets, you feel nothing but happiness, and see only the prettiest of colors! You wonder what blue tastes like. And when can you get more of this stuff?",
}

ITEM.functions.Use = {
onRun = function(item)
  local drug = ents.Create("durgz_lsd")
  drug:SetPos(item.player:GetPos())
  drug:Spawn()
  drug:Use(item.player, item.player, USE_ON, 1)
  item.player:EmitSound("drugs/acid.wav")
  item.player:ChatPrint(table.Random(effectText))
end
}
