ITEM.name = "Hardfire"
ITEM.desc = "A small cardboard box filled with thin almost paper-like strips."
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.duration = 120
ITEM.category = "Drugs"
ITEM.flag = "z"
ITEM.attribBoosts = {
	["end"] = 50,
	["stm"] = 50,
}
ITEM.iconCam = {
	pos = Vector(-89.632080078125, -75.34774017334, 54.501823425293),
	ang = Angle(25, 40, 0),
	fov = 6.1111111111111
}

ITEM.price = 60

local effectText = {
	"Your heart starts beating faster and faster and you can't shake this feeling of anxiety and fear. On top of this, you also feel - no - you *are* faster. Your reflexes are twice as quick even! But you still gotta get out of there *now*.",
}

ITEM.functions.Use = {
onRun = function(item)
  local drug = ents.Create("durgz_mushroom")
  drug:SetPos(item.player:GetPos())
  drug:Spawn()
  drug:Use(item.player, item.player, USE_ON, 1)
  item.player:ChatPrint(table.Random(effectText))
    item.player:EmitSound("drugs/shrooms.wav")
  item.player:ScreenFade(1, Color(255, 255, 255, 255), 3, 0)
end
}

